const cors = require('cors');
const express = require('express');

const cards = require('./cards.js');
const hands = require('./hands.js');

const app = express();
const port = 8888;

// apply our application level middleware
app.use(cors());
app.use(express.json());

// use the prefix /cards
// add the cards router to the express application
app.use('/cards', cards);

// use the prefix /hands
// add the hands router to the express application
app.use('/hands', hands);

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
