const router = require('express').Router();

const deckofcards = require('deckofcards');

const collection = require('../db/collection');

const _formatCards = (response) => {
    // use map create a smaller object with only the needs information
    // card display text and the code
    return response.cards.map((card) => {
        return { card: `${card.value} of ${card.suit}`, code: card.code };
    });
};

const _findAndRemove = (original, throwaway) => {
    // takes an array of objects like [{ card: 'Ace of Hearts', code 'AH'}]
    // and maps to an array of card code string like ['AH']
    const throwawayCodes = throwaway.map((card) => card.code);

    // use the filter method on the original cards array (array of objects) to return a new array
    return original.filter((card) => {
        // if the card.code is NOT included in the throwawayCodes array (array of strings) then keep it
        return !throwawayCodes.includes(card.code);
    });
};

// GET /cards/play
router.get('/play', async (req, res) => {
    try {
        const { shuffle = true } = req.query;
        const count = 5;

        // get a deck of cards that are either shuffled or not shuffled depending on the user input
        const { deck_id } = await deckofcards.buildDeck(shuffle);
        const cards = await deckofcards.drawCards(deck_id, count);

        // format the cards array
        const originalHand = _formatCards(cards);

        // respond with a 200 JSON response
        res.json({ originalHand, deck_id });
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

// POST /cards/throwaway
router.post('/throwaway', async (req, res) => {
    try {
        const { throwaway, originalHand, deck_id } = req.body;

        // find and remove the cards from the original hand that need to be thrown away
        const filterCards = _findAndRemove(originalHand, throwaway);

        // draw the same number of cards that were thrown away
        const cards = await deckofcards.drawCards(deck_id, throwaway.length);

        // format the newly drawn cards array
        const newCards = _formatCards(cards);

        // concat the filtered hand and the new cards to make a complete 5 card hand
        const finalHand = filterCards.concat(newCards);

        // add data about cards hands to the file-system "database"
        collection.add({
            deck_id,
            originalHand,
            throwawayCards: throwaway,
            throwawayCount: throwaway.length,
            finalHand
        });

        // respond with a 200 JSON response
        res.json({ finalHand, deck_id });
    } catch (error) {
        res.status(500).json({ error: error.toString() });
    }
});

module.exports = router;
