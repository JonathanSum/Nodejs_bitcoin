//skincare-api.herokuapp.com/product?q=rose

const superagent = require('superagent');

// config file to hold the base url (and API key where applicable)
const config = require('./config.json');

const search = async (keyword) => {
    try {
        const url = 'https://skincare-api.herokuapp.com';
        const response = await superagent.get(`${url}/product?q=${keyword}`);
        console.log(response.body);
        return response.body;
    } catch (error) {
        return error;
    }
};
search('rose');
